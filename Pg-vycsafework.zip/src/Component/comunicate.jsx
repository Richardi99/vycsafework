
export const Comunicate = ({comunicate}) => {
    return (
        <div className="bar-contact">
            { comunicate && <h3>Comunícate con nosotros al +51 903287955</h3>}
        </div>
    )
}